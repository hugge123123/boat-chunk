# Hugoh4x0r BoatFly (Minecraft 1.21.11)

This is a **separate client-side Fabric addon**, not a modified copy of `hugoh4x0r-0.1.0.jar`. It can be installed alongside that mod.

## Default controls
- **G** — toggle BoatFly on/off
- **W** — forward
- **S** — backward
- **A** — left
- **D** — right
- **Space** — rise
- **Left Shift** — descend

## Change keybinds
Open **Options → Controls → Key Binds**. Search for the BoatFly entries and click a binding to assign another key. All seven controls (toggle, forward, back, left, right, up, down) are individually rebindable. Minecraft will flag conflicting key assignments.

The feature only applies while the player is riding a boat. Use only where the server rules allow client-side flight/modifications.

## Build
Requires Java 21 and internet access for Gradle to download Fabric/Minecraft dependencies.

1. Open this folder in IntelliJ IDEA, or install Gradle.
2. Run `gradle build` (or use a Gradle wrapper if you add one).
3. The resulting JAR will be in `build/libs/`.
4. Put the JAR in `.minecraft/mods/` alongside Fabric API and your other mods.

## Important
This source project has not been compiled or tested in this environment. If the Minecraft 1.21.11 mappings/API changed, a small adjustment may be needed. It is not yet a verified ready-to-use JAR.
